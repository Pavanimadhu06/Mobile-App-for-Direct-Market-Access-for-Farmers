export { default as Logo } from "./logo.png";
export { default as SplashImg } from "./splash_img.png";
export { default as Avator } from "./avator.png";
export { default as Vegetables } from "./categories/vegetables.jpeg";
export { default as Fruits } from "./categories/fruits.jpeg";
export { default as Grains } from "./categories/grains.jpeg";
export { default as Dairy } from "./categories/dairy.jpeg";